"""
This program imports all of the functions from the calculation program
to the main function in order to get the wholesale price of a product.
Name: Cristian Pintor
"""

from calculation import *

def main():
    # Get the item's wholesale cost.
    another = ''
    wholesale = 0
    calculation(another, wholesale)

main()

